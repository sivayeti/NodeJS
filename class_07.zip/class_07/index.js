
const http = require('http') //Importing global Module, we no need to specify the path , directly specify the 'Module name'

//To import the exported local modules , we have to use these syntax
const { addNumber, subtractNumber, divideNumber, multiplyNumber } = require('./demomodule') //when importing the local modules , we need to specfy the path


console.log(addNumber(10, 11)) 
console.log(subtractNumber(10, 5)) 
console.log(divideNumber(10, 2)) 
console.log(multiplyNumber(10, 5)) 
