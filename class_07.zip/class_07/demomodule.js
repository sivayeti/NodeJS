
function addNumber(a, b){
    return a+b
}

function subtractNumber(a, b){
    return a-b
}


function divideNumber(a, b){
    return a/b
}

function multiplyNumber(a, b){
    return a*b
}

//we have to export the modules, to use in other code files
module.exports = {addNumber, subtractNumber, divideNumber, multiplyNumber}
//The modules which we want to export that should enclose within curly braces and assigned to 'module.export'

//Exported modules, if we want to use in any other files, then in that files we have to import the exported local modules in that file.


