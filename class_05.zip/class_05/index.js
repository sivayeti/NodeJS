

const fs = require('fs') //importing fs module

//1.Reading Files
//By using these FS module , we can read the contents in demo.txt

//fs.readFile("file_name", "encoder(which converts our output into string format", "function")

fs.readFile("demo.txt", "utf8", (err, data) => {
     if(err){
       console.log(err) 
     }
     console.log(data)
})


//2.Creating files
//Lets dynamically create the files
//fs.writeFile("FileName", "content", "function")

// fs.writeFile('example.html', 'utf8', (err)=>{

//     if(err){
//         console.log(err)
//     }
//     console.log("File Created Successfully")
// })



//3. writing in Files

const contentSample = "My name is Sivamani, I am creating dynamic content"

// fs.writeFile('example.html',  contentSample, (err)=>{
   
//     if(err){
//         console.log(err)
//     }else{
//         console.log('File content is success')
//     }
// })


// fs.writeFile('example.html',  "Hello siva", (err)=>{
   
//     if(err){
//         console.log(err)
//     }else{
//         console.log('File content is success')
//     }
// })


fs.writeFile("example2.html","", (err) => {
    if(err){
        console.log(err);
    }else{
        console.log('File Content is success')

    }
})


//4.File renaming
//fs.rename('old_file_name', 'new_file_name', function)
// fs.rename('example.html', 'newChangedFile.js', (err)=>{
//     if(err){
//         console.log(err)
//     }else{
//         console.log("modified success")
//     }

// })


//5.File Deletion
//fs.unlink('file_name')
fs.unlink('example2.html', (err)=>{
    if(err){
        console.log(err)
    }else{
        console.log("File Deleted Success")
    }
})

