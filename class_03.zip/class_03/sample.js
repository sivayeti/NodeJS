
console.log("Hello World");

function addNumber(a, b){
    console.log(a+b)
}

addNumber(150, 250)