

const http = require('http') //import http module

//By using createServer() method in http , we can create the server
const myServer = http.createServer(
    (request, response)=>{
         //we can define the respnse which we want to send to client by using write()'
         response.write("Welcome to Server")
         response.end()
    }
) //These is the server which we created , to communicate with these server , we need port numnber
//for to communicate with our server, we need to create a port number for our server

//By using the listen() method we can create the port number for our server
//server_name.listen(to which port number we decided to communicate with server, that port number we have to pass here, )

myServer.listen(5500)