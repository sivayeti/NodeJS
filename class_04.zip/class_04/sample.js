
//1.OS module

const os = require('os');//1st a fall, we have to import the 'os' module by using require('os') in a variable, then only we can display our os details.
//using 'os' module
//These os module is used to know about our os model details

//Read File
console.log(os.type()) //describes our os type
console.log(os.version()) //describes the version of our os
console.log(os.freemem()) //to know about the free-memory space in os
console.log(os.cpus())  //to display the status of cpu in os

//we can output the os details, by using or accessing the 'os' module by require('os')


//create file
//current folder or file , if we want to interact

//__dirname, to display the current folder
//__filename to display the current files

console.log(__dirname)
console.log(__filename)




//2.path module
const path = require('path') //to print the current directory

console.log(path.dirname(__filename))  //to print the current directory path
console.log(path.basename(__filename)) //to print only current file name
console.log(path.extname(__filename)) //to print the extension of current file

//Dynamic content
console.log(path.parse(__filename))//to print current file name,extension name,basename, directory path, root 


